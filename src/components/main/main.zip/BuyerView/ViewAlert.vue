<template>
  <div>
     <div class="showLocation">
        <b></b>
        <div>
          <p>{{address}}</p>
          <p style="margin-top:10px;">{{userName}}<span style="margin-left:40px;">{{userTel}}</span></p>
        </div>
      </div> 
  </div>
</template>

<script>
export default {
  name:'ViewAlert',
  data () {
    return {
    
    };
  },

  components: {},

  methods: {
    
  }
}

</script>
<style>

</style>