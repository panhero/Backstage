<template>
<p>AfterSale</p>
</template>

<script>
export default {
  name:'AfterSale',
  data () {
    return {
    };
  },

  components: {},

  methods: {}
}

</script>
<style>
</style>