<template>
<p> this is WaitDeliver</p>
</template>

<script>
export default {
  name:'WaitDeliver',
  data () {
    return {
    };
  },

  components: {},

  methods: {}
}

</script>
<style>
</style>