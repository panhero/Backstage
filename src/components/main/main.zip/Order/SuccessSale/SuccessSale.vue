<template>
<p>成功订单 SuccessSale </p>
</template>

<script>
export default {
  name:'SuccessSale',
  data () {
    return {
    };
  },

  components: {},

  methods: {}
}

</script>
<style>
</style>